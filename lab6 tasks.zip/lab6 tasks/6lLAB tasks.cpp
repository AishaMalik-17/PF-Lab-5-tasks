#include<iostream>
using namespace std;
int main(){
	int i;
	
	for(i=2;i<=20;i+=3){
		cout<<i<<endl;
	}
	return 0;
}
